(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_blogs_page_e38716.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_blogs_page_e38716.js",
  "chunks": [
    "static/chunks/_539d2d._.js"
  ],
  "source": "dynamic"
});
