(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_upload_page_e38716.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_upload_page_e38716.js",
  "chunks": [
    "static/chunks/_ea46d1._.js",
    "static/chunks/node_modules_@monaco-editor_react_dist_index_mjs_e0d04f._.js"
  ],
  "source": "dynamic"
});
