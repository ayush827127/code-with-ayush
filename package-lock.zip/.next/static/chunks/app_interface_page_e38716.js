(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_interface_page_e38716.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_interface_page_e38716.js",
  "chunks": [
    "static/chunks/_741a47._.js"
  ],
  "source": "dynamic"
});
