(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_designs_page_e38716.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_designs_page_e38716.js",
  "chunks": [
    "static/chunks/app_86ee54._.js"
  ],
  "source": "dynamic"
});
