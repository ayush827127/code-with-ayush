(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_e38716.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_e38716.js",
  "chunks": [
    "static/chunks/_ff6a35._.js",
    "static/chunks/node_modules_f6f170._.js"
  ],
  "source": "dynamic"
});
