(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_61af54.js",
  "chunks": [
    "static/chunks/[root of the server]__501b62._.css",
    "static/chunks/node_modules_@firebase_auth_dist_esm2017_750ccb._.js",
    "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4b._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_8dd274._.js",
    "static/chunks/_4e225e._.js"
  ],
  "source": "dynamic"
});
