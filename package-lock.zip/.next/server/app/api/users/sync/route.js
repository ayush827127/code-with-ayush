const CHUNK_PUBLIC_PATH = "server/app/api/users/sync/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_next_dist_5d2fa3._.js");
runtime.loadChunk("server/chunks/[root of the server]__122110._.js");
runtime.loadChunk("server/chunks/_c029ed._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/users/sync/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/users/sync/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
